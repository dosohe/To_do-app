//
//  AddTodoController.swift
//  IOSApplication
//
//  Created by Andrew on 05/01/2019.
//  Copyright © 2019 Andrew. All rights reserved.
//

import UIKit
import SwiftyJSON;
import Alamofire;

protocol Updater {
    func Switcher(switchState:Bool)
}


class AddTodoController: UITableViewController {
    
    // outlet for AddTodoScreen
    @IBOutlet var table: UITableView!

    var delegate:Updater? = nil
    
     var project_num:[String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        table.selectRow(at: IndexPath(row: 0, section: 1), animated: false, scrollPosition: .none)
        table.cellForRow(at: IndexPath(row: 0, section: 1))?.accessoryType = .none
    }
    
    
    // Display functions
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return section == 0 ?  1 : project_num.count
    }
    
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableCell(withIdentifier: "header")
        header?.textLabel?.text = section == 0 ? "Задача":"Категория"
        return header
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 55
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section==0{ return 60 }else{ return 45 }
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "newtodo", for: indexPath) as! TodoTextCell
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "newcell", for: indexPath)
            cell.textLabel?.text = project_num[indexPath.row]
            return cell
        }
    }

    // Checkmarks for rows
    override func tableView(_ tableView: UITableView, didHighlightRowAt indexPath: IndexPath) {
        if indexPath.section != 0 {
        for cell in tableView.visibleCells{
            cell.accessoryType = .none
        }
        tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
            print(indexPath)
        }
    }
    
    // Done button action
    @IBAction func submit(_ sender: Any) {
        if ((table.cellForRow(at: IndexPath(row: 0, section: 0)) as! TodoTextCell).todo_field.text?.isEmpty)!{
            let alert = UIAlertController(title: "Отсорожно", message: "Введите название задачи и выберите категорию", preferredStyle:.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel){ (alertAction) in })
            self.present(alert, animated: true, completion: nil)
        }
        else{
            let json:Parameters = [ "text":(table.cellForRow(at: IndexPath(row: 0, section: 0)) as! TodoTextCell).todo_field.text!,
                                    "project_id": (table.indexPathForSelectedRow?.row)!+1]
            Alamofire.request("https://cryptic-thicket-73335.herokuapp.com/todos", method: .post, parameters: json, encoding: JSONEncoding.default)
            delegate?.Switcher(switchState: true)
            self.dismiss(animated: true, completion: nil)
        }
        
    }
    // Back botton action
    @IBAction func close(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

    
}
