//
//  TodoCell.swift
//  IOSApplication
//
//  Created by Andrew on 04/01/2019.
//  Copyright © 2019 Andrew. All rights reserved.
//


import UIKit

class TodoCell: UITableViewCell {
    
    @IBOutlet weak var check_box: UIView?
    @IBOutlet weak var todo_text: UILabel?
    

    
}
