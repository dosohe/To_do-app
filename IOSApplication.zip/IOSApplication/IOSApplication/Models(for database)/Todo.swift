//
//  File.swift
//  IOSApplication
//
//  Created by Andrew on 05/01/2019.
//  Copyright © 2019 Andrew. All rights reserved.
//

import Foundation
import SwiftyJSON;

class Todo{
    var id:Int
    var text:String
    var isCompleted:Bool
    
    init(id: Int, text: String, isCompleted: Bool){
        self.id = id
        self.text = text
        self.isCompleted = isCompleted
    }
    
    
    init(json: JSON){
        self.id = json["id"].int!
        self.text = json["text"].string!
        self.isCompleted = json["isCompleted"].bool!
    }
}

