//
//  Project.swift
//  IOSApplication
//
//  Created by Andrew on 05/01/2019.
//  Copyright © 2019 Andrew. All rights reserved.
//

import Foundation


class Project{
    var title:String
    var todos:[Todo]
    
    init(title: String, todos: [Todo]){
        self.title = title
        self.todos = todos
    }
    
    init(title: String){
        self.title = title
        self.todos = []
    }
    
    init(todos: [Todo]){
        self.title = ""
        self.todos = todos
    }
    
    func addTodo(todo: Todo){
        todos.append(todo)
    }
}
