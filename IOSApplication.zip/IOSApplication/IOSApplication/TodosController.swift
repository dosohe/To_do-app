//
//  ViewController.swift
//  IOSApplication
//
//  Created by Andrew on 04/01/2019.
//  Copyright © 2019 Andrew. All rights reserved.
//

import UIKit
import M13Checkbox;
import Alamofire;
import SwiftyJSON;

class TodosController: UITableViewController, Updater{

    @IBOutlet var table: UITableView!
    var projects: [Project] = []

    func Switcher(switchState:Bool){
        UpdateData()
    }
    
    func UpdateData(){
        Alamofire.request("https://cryptic-thicket-73335.herokuapp.com/get_json").responseJSON {
            response in switch response.result{
            case .success:
                self.projects = []
                let json = JSON(response.result.value!)
                
//                        print("JSON: \(json[0]["todos"])")
                for (_,subJson):(String, JSON) in json {
//                        print(subJson["todos"][0])
//                        self.projects.append(Project(title: subJson["title"].string!, todos: [Todo(json: subJson["todos"][0])]))
                    self.projects.append(Project(title: subJson["title"].string!))
                    
                }
                
                for num in 0...2{
                    for (_,subJson):(String, JSON) in json[num]["todos"] {
//                        print(json[num]["todos"] )
                        let project_id = (subJson["project_id"].int)! - 1
                        self.projects[project_id].addTodo(todo: Todo(json: subJson))
                        
                    }
                    
                }
                self.table.reloadData()
            default:
                print( "Error" )
            }
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UpdateData()

        
    }
    
    
//    Main functions for Display data
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //возвращаем количество задач внутри проекта, который находим, используя section
        
        return self.projects[section].todos.count
        
    }
    
    
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableCell(withIdentifier: "header")
        
        header?.textLabel?.text = self.projects[section].title
        
        return header
    }

    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {

        return 50

        //высота заголовка (название проекта)

    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
       //высота cell (непосредственно само todo)
        
        return 45
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TodoCell
        cell.todo_text!.text = self.projects[indexPath.section].todos[indexPath.row].text
        
// Let`s set the current isCompleted from http
        if self.projects[indexPath.section].todos[indexPath.row].isCompleted{
            (cell.check_box as! M13Checkbox).setCheckState(M13Checkbox.CheckState.checked, animated: false)
        }
        else{
            (cell.check_box as! M13Checkbox).setCheckState(M13Checkbox.CheckState.unchecked, animated: false)
            
        }
        TextDecoration(cell: cell)
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! TodoCell
        (cell.check_box as! M13Checkbox).toggleCheckState()
//        self.projects[indexPath.section].todos[indexPath.row].isCompleted = !self.projects[indexPath.section].todos[indexPath.row].isCompleted
        TextDecoration(cell: cell);
//        print(self.projects[indexPath.section].todos[indexPath.row].id)
//        print(self.projects[indexPath.section].todos[indexPath.row].isCompleted)
        
        Alamofire.request("https://cryptic-thicket-73335.herokuapp.com/todos/" +
            String(self.projects[indexPath.section].todos[indexPath.row].id), method: .put)


    }
//TextLineCross from M13Checkbox
        func TextDecoration(cell: TodoCell){
            let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string: (cell.todo_text?.text)!)
            if (cell.check_box as! M13Checkbox).checkState == M13Checkbox.CheckState.checked{
                attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 1, range: NSMakeRange(0, attributeString.length))
            }else{
                attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 1, range: NSMakeRange(0, 0))
            }
            cell.todo_text?.attributedText = attributeString;
        }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        //возвращаем количество секций (проектов)
        
        return self.projects.count
        
    }
// to form and transport an array of projects
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            var project_num:[String] = []
            for project in self.projects{ project_num.append(project.title) };
    
            let key = segue.destination as! UINavigationController
            ( (key).topViewController as! AddTodoController ).project_num = project_num
            ( (key).topViewController as! AddTodoController ).delegate = self
        }
    

}

